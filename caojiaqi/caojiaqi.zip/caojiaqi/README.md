# indal

This repo include all following functions:
1, Login, logout, registion, password resetting;
2, Notification;
3, Add, drop courses;
4, Course Tree.

Team Members:
Jinkun Chen (B00754386)
Yijie Yao (B00745727)
Xuemin Yu (B00743075)
Yang shu (B00686777)
Jiaqi Cao (B00754380)
Yujiao Wang (B00725482)
Yu Zhang (B00726249)
Di Kuang (B00749417)